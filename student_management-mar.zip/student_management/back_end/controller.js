 var connection=require('./dp')

 const show=(req,res)=>{
var view="select * from student";
 connection.query(view,function(err,result){
  if(err){
          res.send({
                     status:400,
                     message:"err",
                      date:err          
                    
                    })

    } 
else{
          res.send({
                     status:200,                      
                     message:"print",
                      data:result
    })  }
})

 }


 const select = (req, res) => {
    var std = "SELECT ,Register_Number,Student_Name,Father_Name,Date_Of_Birth,Gender,Date_Of_Admission,Class,Fees_Details,Address,Mobile_Number FROM `students-login` WHERE roll_no=?"
    connection.query(std, [req.body.id], function (err, result) {
        if (err) {
            res.send({
                status: 400,
                message: "err",
                data: err

            })
        }
        else if (result.length > 0) {
            res.send({
                status: 200,
                message: "success",
                data: result
            })
        }
        else {
            res.send({
                status: 200,
                message: "Students data not found",
                data: result
            })

        }

    })
}



 const insert=(req,res)=>{
 var inset="insert into  student(Register_Number,Student_Name,Father_Name,Date_Of_Birth,Gender,Date_Of_Admission,Class,Fees_Details,Address,Mobile_Number) value(?,?,?,?,?,?,?,?,?,?)";
 connection.query(inset,[req.body.Register_Number,req.body.Student_Name,req.body.Father_Name,req.body.Date_Of_Birth,req.body.Gender,req.body.Date_Of_Admission,req.body.Class,req.body.Fees_Details,req.body.Address,req.body.Mobile_Number],
function(err,result){
    if(err){
        res.send({
                   status:400,
                   message:"err",                  
                  date:err

        })

  } 
 else{
        res.send({
                   status:200,
                   message:"print",
                   data:result
                             
})
 }
 })
 
 }







const update = (req, res) => {
    var updat = "UPDATE `student` SET Register_Number=?,Student_name=?,Father_Name=?,Date_Of_Birth=?,Gender=?,Date_Of_Admission=?,Class=?,Fees_Details=?,Address=?,Mobile_Number=? WHERE Id=?";
    connection.query(updat, [req.body.Register_Number, req.body.Student_Name, req.body.Father_Name, req.body.Date_Of_Birth,req.body.Gender,req.body.Date_Of_Admission,req.body.Class,req.body.Fees_Details,req.body.Address,req.body.Mobile_Number,req.body.Id], function (err, result) {
        if (err) {
            res.send({
                status: 400,
                message: "err",
                data: err
             })
        }
         else if (result.affectedRows<=0) {
             res.send({
                 status: 400,
                 message: "data not entered",
                 data: result
            })
        }
        else {
            res.send({
                status: 200,
                message: "sucess",
                data: result
           })
       }
    }

    )
 }
 


const dele = (req, res) => {
     var del = "DELETE FROM `student` where Id=?";
                    connection.query(del, [req.body.Id], function (err, result) {
                        console.log(req.body.Id);
                        if (err) {
                            res.send({
                                status: 400,
                               message: "err",
                                data: err
                            })
                     }
                       else if (req.body.Id==null || req.body.Id==undefined) {
                             res.send({
                                status: 400,
                                message: "parameter undefined",
                                data: result
                            })
                        }
                        else{
                            res.send({
                                status: 200,
                                message: "deleted successfully",
                                data: result
                            })
                        }
                    })
                   }
 module.exports={show,select,insert,update,dele};
 


