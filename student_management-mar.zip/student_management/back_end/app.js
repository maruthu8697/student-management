var db=require('./dp')
var express=require('express')
var cors=require('cors')
const port=3333;
db.connect(
    (err)=>{
     if(err) 

     {console.log(err);}
     else 
     {console.log("dp connect");} 
    })
     
    
    var app=express()
    app.use(cors())
    app.use(express.json())
    app.listen(port)
    app.use(require('./router'))