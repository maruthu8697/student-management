const express=require('express');
const router=express.Router();
const control=require('./controller')


router.get('/ge',control.show);
router.get('/gete',control.select);
router.post('/post',control.insert);
router.post('/Edit',control.update);
router.post('/pos',control.dele);
module.exports=router;