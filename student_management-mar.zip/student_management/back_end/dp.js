var dp=require('mysql');
var connection=dp.createConnection({host:"localhost",user:"root",password:"1234567",database:"management"});
module.exports=connection;

