-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               8.0.32 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             12.3.0.6589
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for management
CREATE DATABASE IF NOT EXISTS `management` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `management`;

-- Dumping structure for table management.student
CREATE TABLE IF NOT EXISTS `student` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Register_Number` int DEFAULT NULL,
  `Student_Name` varchar(200) DEFAULT NULL,
  `Father_Name` varchar(200) DEFAULT NULL,
  `Date_Of_Birth` date DEFAULT NULL,
  `Gender` enum('Male','Female') DEFAULT NULL,
  `Date_Of_Admission` date DEFAULT NULL,
  `Class` varchar(200) DEFAULT NULL,
  `Fees_Details` varchar(200) DEFAULT NULL,
  `Address` varchar(200) DEFAULT NULL,
  `Mobile_Number` bigint DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table management.student: ~8 rows (approximately)
INSERT INTO `student` (`Id`, `Register_Number`, `Student_Name`, `Father_Name`, `Date_Of_Birth`, `Gender`, `Date_Of_Admission`, `Class`, `Fees_Details`, `Address`, `Mobile_Number`) VALUES
	(1, 1001, 'Vetrivel', 'Ganesan', '2009-06-06', 'Male', '2012-06-03', 'IX', 'Paid', 'Madurai', 8767894534),
	(2, 1002, 'Manoj', 'Kumar', '2009-05-02', 'Male', '2012-07-03', 'X', 'Paid', 'karur', 9643672672),
	(3, 1003, 'Ukesh', 'Vengat', '2009-09-11', 'Male', '2011-09-02', 'X', 'Pending', 'Melur', 9677777776),
	(4, 1004, 'Abinesh', 'Chinnasamy', '2009-01-12', 'Male', '2012-08-12', 'IX', 'Paid', 'Theni', 9645347865),
	(5, 1005, 'ramesh', 'madhan', '2022-03-22', 'Male', '2022-09-11', 'X', 'pending', 'adyar', 27532457247),
	(6, 1006, 'raju', 'Rajan', '2008-06-07', 'Male', '2022-07-05', 'X', 'pending', 'theni', 34757545723),
	(7, 1007, 'Maneshwar', 'Mahendran', '2009-06-10', 'Male', '2012-10-10', 'IX', 'Paid', 'Madurai', 9879876545),
	(8, 1008, 'Bramman', 'Gobi', '2008-03-12', 'Male', '2012-01-12', 'X', 'Pending', 'Dindigul', 8765453247);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
