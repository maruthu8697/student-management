const select=()=>{
  fetch('http://localhost:3333/ge', {
   method: 'get', // or 'PUT'
  
  headers: {
    'Content-Type': 'application/json',
  },
  body:JSON.stringify(),
  })
  .then((response) => response.json())
  .then((data) => {
    console.log('Success:', data);
    let dat=data.data;
    show(dat);
  })
  
  
  function show(data) {
   let neww=

    `<tr style="background-color:grey; height:1cm;">
      <th>Id</th>
      <th>Register Number</th>
      <th>Student Name</th>
      <th>Father name</th>
      <th>Date Of Birth</th>
      <th>Gender</th>
      <th>Date Of Admission</th>
      <th>class</th>
      <th>Fees Details</th>
      <th>Address</th>
      <th>Mobile Number</th>
    </tr>`;
      
   data.map((r)=> {  
    {
              console.log(r); 
              neww += `<tr>
          <td>${r.Id}</td>
          <td>${r.Register_Number} </td>
          <td>${r.Student_Name}</td>
          <td>${r.Father_Name}</td>
          <td>${r.Date_Of_Birth}</td> 
          <td>${r.Gender}</td> 
          <td>${r.Date_Of_Admission}</td>
          <td>${r.Class}</td> 
          <td>${r.Fees_Details}</td>
          <td>${r.Address}</td>
          <td>${r.Mobile_Number}</td>
          </tr>`;
          }        
   })
   document.getElementById('student').innerHTML= neww;
  }
  }
  select();
    const insert=()=>{
        console.log("enter into api");
    
      var re=document.getElementById('rnumber').value;
      var st=document.getElementById('sname').value;
      var fa=document.getElementById('fname').value;
      var dab=document.getElementById('dob').value;
      var ge=document.getElementById('gen').value;
      var daa=document.getElementById('doa').value;
      var cl=document.getElementById('cla').value;
      var fe=document.getElementById('fdetails').value;
      var ad=document.getElementById('ads').value;
      var mo=document.getElementById('mnumber').value;
      
  
      // console.log(i,rn,sn,fn,db,ge,da,cl,fd,ad,mn);
    
      fetch('http://localhost:3333/post', {
        method: 'POST', // or 'PUT'
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
                   
          "Register_Number":re,
          "Student_Name":st,
          "Father_Name":fa,
          "Date_Of_Birth":dab,
          "Gender":ge,
          "Date_Of_Admission":daa,
          "class":cl,
          "Fees_Details":fe,
          "Address":ad,
          "Mobile_Number":mo


        }),
      })
        .then((response) => response.json())
        .then((data) => {
          console.log('Success:', data);
          if(data.status==200){
            window.location.href="front.html";
            localStorage.setItem('student',JSON.stringify(data.data))
          }
        })
      }


      
    const update=()=>{
      console.log("enter into api");
  
    let ab=document.getElementById('id').value;
    let re=document.getElementById('rnumber').value;
    let st=document.getElementById('sname').value;
    let fa=document.getElementById('fname').value;
    let dab=document.getElementById('dob').value;
    let ge='male';
    let daa=document.getElementById('doa').value;
    let cl=document.getElementById('cla').value;
    let fe=document.getElementById('fdetails').value;
    let ad=document.getElementById('ads').value;
    let mo=document.getElementById('mnumber').value;
    
    
    

    // console.log(i,rn,sn,fn,db,ge,da,cl,fd,ad,mn);
  
    fetch('http://localhost:3333/Edit', {
      method: 'POST', // or 'PUT'
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({

        "Id":ab,      
        "Register_Number":re,
        "Student_Name":st,
        "Father_Name":fa,
        "Date_Of_Birth":dab,
        "Gender":ge,
        "Date_Of_Admission":daa,
        "Class":cl,
        "Fees_Details":fe,
        "Address":ad,
        "Mobile_Number":mo
      }),
    })
      .then((response) => response.json())
      .then((data) => {
        console.log('Success:', data);
        if(data.status==200){
          window.location.href="front.html";
        }
        
      })
    }

const dele=()=>{
var dids=document.getElementById('did').value;
fetch('http://localhost:3333/pos', {
method: 'POST', // or 'PUT'
headers: {
  'Content-Type': 'application/json',
},
body: JSON.stringify({
  "Id":dids
}),
})
.then((response) => response.json())
.then((data) => {
  console.log('Success:', data);
  if(data.status==200){
    window.location.href="front.html";
    localStorage.setItem('student',JSON.stringify(data.data))
  }
 
})
}